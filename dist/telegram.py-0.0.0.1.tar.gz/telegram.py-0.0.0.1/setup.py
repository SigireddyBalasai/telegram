import setuptools
setuptools.setup(
  name = "telegram.py",
  version = "0.0.0.1",
  author = "BalasaiSigireddy",
  description = "attemptof api wrapper to telegram",
  packages = ["telegram"]
)
